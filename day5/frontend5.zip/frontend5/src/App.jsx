import React, { useState } from "react";
import ChatBox from "./ChatBox";
import "./App.css";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);

  // Handle login and signup
  const handleSubmit = async (e) => {
    e.preventDefault();

    const url = isLogin
      ? "http://localhost:8000/login"
      : "http://localhost:8000/signup";

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      setMessage(data.message);

      // Move to ChatBox if login success
      if (data.message.includes("successful")) {
        setLoggedIn(true);
      }
    } catch (error) {
      console.error("Error:", error);
      setMessage("Something went wrong.");
    }
  };

  // If logged in, show ChatBox
  if (loggedIn) {
    return <ChatBox username={username} />;
  }

  return (
    <div className="auth-container">
      <h1>Contract AI Application</h1>
      <div className="auth-card">
        <h2>{isLogin ? "Login" : "Signup"}</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">
            {isLogin ? "Login" : "Signup"}
          </button>
        </form>
        <p>{message}</p>
        <button
          onClick={() => setIsLogin(!isLogin)}
          className="switch-btn"
        >
          Switch to {isLogin ? "Signup" : "Login"}
        </button>
      </div>
    </div>
  );
}

export default App;
