import React, { useState } from "react";

function ChatBox({ username }) {
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("");
  const [comments, setComments] = useState([]);

  const handleUpload = async () => {
    if (!file) return alert("Please upload a file first.");
    const formData = new FormData();
    formData.append("file", file);

    const res = await fetch("http://localhost:8000/upload", {
      method: "POST",
      body: formData,
    });
    const data = await res.json();
    setText(data.text);
  };

  const handleHighlight = () => {
    const selected = window.getSelection().toString();
    if (!selected) return;

    const tag = prompt("Enter tag (example: Risk, Obligation):");
    const comment = prompt("Add comment:");
    if (!tag || !comment) return;

    fetch("http://localhost:8000/save-redline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, section: selected, tag, comment }),
    });

    setComments([...comments, { tag, comment, section: selected }]);
    alert("Comment saved.");
  };

  const handleChat = async () => {
    if (!message.trim()) return;
    const res = await fetch("http://localhost:8000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();
    setReply(data.reply);
  };

  return (
    <div className="chat-container">
      <h1>Contract Analyzer</h1>
      <div className="upload-box">
        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
        <button onClick={handleUpload}>Upload File</button>
      </div>

      <div className="text-display" onMouseUp={handleHighlight}>
        <h3>Extracted Text</h3>
        <div className="text-content">
          {text || "Upload a PDF file to extract text here."}
        </div>
      </div>

      <div className="saved-comments">
        <h3>Saved Comments</h3>
        {comments.length === 0 ? (
          <p>No comments yet.</p>
        ) : (
          comments.map((c, i) => (
            <div key={i} className="comment-item">
              <b>{c.tag}</b>: {c.comment}
              <br />
              <i>{c.section.slice(0, 60)}...</i>
            </div>
          ))
        )}
      </div>

      <div className="chat-section">
        <h3>Ask AI</h3>
        <input
          type="text"
          placeholder="Ask a question..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button onClick={handleChat}>Chat</button>
        <p>{reply}</p>
      </div>
    </div>
  );
}

export default ChatBox;
