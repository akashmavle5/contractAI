import React, { useState } from "react";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");

  // Handle Login and Signup
  const handleSubmit = async (e) => {
    e.preventDefault();

    const url = isLogin
      ? "http://localhost:8000/login"
      : "http://localhost:8000/signup";

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    setMessage(data.message);

    if (data.message.includes("successful")) {
      setLoggedIn(true);
    }
  };

  // Handle File Upload
  const handleUpload = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch("http://localhost:8000/upload", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();
    setText(data.text);
  };

  // After Login Page
  if (loggedIn) {
    return (
      <div style={{ textAlign: "center", marginTop: 40 }}>
        <h1>Contract Upload and Extraction</h1>

        <form onSubmit={handleUpload}>
          <input
            type="file"
            accept=".pdf,.docx"
            onChange={(e) => setFile(e.target.files[0])}
          />
          <button type="submit">Upload</button>
        </form>

        <div
          style={{
            marginTop: 20,
            textAlign: "left",
            width: "80%",
            margin: "auto",
          }}
        >
          <h3>Extracted Contract Text (Highlight to Tag)</h3>
          <p
            onMouseUp={() => {
              const selectedText = window.getSelection().toString();
              if (selectedText) {
                const tag = prompt(
                  "Tag this selection (Example: Risk, Obligation, Metadata)"
                );
                const comment = prompt("Add a comment:");
                if (tag) {
                  fetch("http://localhost:8000/save-redline", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      username,
                      section: selectedText,
                      tag,
                      comment,
                    }),
                  });
                  alert("Redline saved!");
                }
              }
            }}
          >
            {text}
          </p>
        </div>

        <button
          onClick={() => setLoggedIn(false)}
          style={{
            marginTop: 20,
            backgroundColor: "#007BFF",
            color: "white",
            border: "none",
            padding: "8px 12px",
            borderRadius: 5,
            cursor: "pointer",
          }}
        >
          Logout
        </button>
      </div>
    );
  }

  // Login and Signup Page
  return (
    <div style={{ textAlign: "center", marginTop: 50, fontFamily: "Arial" }}>
      <h1>Contract AI Application</h1>

      <div
        style={{
          margin: "20px auto",
          padding: 20,
          width: 320,
          border: "1px solid #ddd",
          borderRadius: 8,
        }}
      >
        <h2>{isLogin ? "Login" : "Signup"}</h2>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{ width: "90%", padding: 8, marginBottom: 10 }}
          />
          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: "90%", padding: 8, marginBottom: 10 }}
          />
          <button
            type="submit"
            style={{
              width: "95%",
              padding: 8,
              background: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: 5,
            }}
          >
            {isLogin ? "Login" : "Signup"}
          </button>
        </form>

        <p style={{ color: message.includes("success") ? "green" : "red" }}>
          {message}
        </p>

        <button
          onClick={() => setIsLogin(!isLogin)}
          style={{
            background: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: 5,
            padding: "6px 10px",
            marginTop: 10,
          }}
        >
          Switch to {isLogin ? "Signup" : "Login"}
        </button>
      </div>
    </div>
  );
}

export default App;
