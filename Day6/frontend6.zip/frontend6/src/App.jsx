import React, { useState } from "react"
import ChatBox from "./ChatBox"
import ContractGenerator from "./ContractGenerator"
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom"
import "./App.css"

function App() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [message, setMessage] = useState("")
  const [isLogin, setIsLogin] = useState(true)
  const [loggedIn, setLoggedIn] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    const url = isLogin ? "http://localhost:8000/login" : "http://localhost:8000/signup"
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      })
      const data = await res.json()
      setMessage(data.message)
      if (data.message.includes("successful")) setLoggedIn(true)
    } catch (error) {
      console.error("Error:", error)
      setMessage("Something went wrong.")
    }
  }

  if (!loggedIn) {
    return (
      <div className="auth-container">
        <h1>Contract AI Application</h1>
        <div className="auth-card">
          <h2>{isLogin ? "Login" : "Signup"}</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Enter Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              placeholder="Enter Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit">
              {isLogin ? "Login" : "Signup"}
            </button>
          </form>
          <p>{message}</p>
          <button onClick={() => setIsLogin(!isLogin)} className="switch-btn">
            Switch to {isLogin ? "Signup" : "Login"}
          </button>
        </div>
      </div>
    )
  }

  return (
    <Router>
      <div style={{ textAlign: "center", marginBottom: 20 }}>
        <Link to="/chat" style={{ margin: 10, textDecoration: "none", color: "blue" }}>
          Chat Analyzer
        </Link>
        <Link to="/generator" style={{ margin: 10, textDecoration: "none", color: "blue" }}>
          Contract Generator
        </Link>
      </div>

      <Routes>
        <Route path="/chat" element={<ChatBox username={username} />} />
        <Route path="/generator" element={<ContractGenerator username={username} />} />
        <Route path="/" element={<ChatBox username={username} />} />
      </Routes>
    </Router>
  )
}

export default App
