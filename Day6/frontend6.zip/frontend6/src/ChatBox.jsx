// src/ChatBox.jsx
import React, { useState, useEffect } from "react";

function ChatBox({ username }) {
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("");
  const [comments, setComments] = useState([]);
  const [clauses, setClauses] = useState([]);
  const [model, setModel] = useState("openai");

  // Load saved redlines and clauses when the page opens
  useEffect(() => {
    fetch("http://localhost:8000/get-redlines")
      .then((r) => r.json())
      .then((d) => {
        console.log("Fetched redlines:", d);
        if (d.redlines) setComments(d.redlines);
      })
      .catch(() => console.log("Error loading redlines"));

    fetch("http://localhost:8000/get-clauses")
      .then((r) => r.json())
      .then((d) => {
        console.log("Fetched clauses:", d);
        if (d.clauses) setClauses(d.clauses);
      })
      .catch(() => console.log("Error loading clauses"));
  }, []);

  // Upload PDF or DOCX and extract text
  const handleUpload = async () => {
    if (!file) return alert("Choose a file first");
    const fd = new FormData();
    fd.append("file", file);

    try {
      const res = await fetch("http://localhost:8000/upload", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      console.log("Extracted text:", data);
      setText(data.text || "");
    } catch (error) {
      alert("Upload failed");
    }
  };

  // Save highlighted section as redline
  const handleHighlightSave = () => {
    const selected = window.getSelection().toString();
    if (!selected) return alert("Select text to save a redline");

    const tag = prompt("Enter tag (e.g. Risk, Obligation):");
    const comment = prompt("Enter comment:");
    if (!tag || !comment) return;

    fetch("http://localhost:8000/save-redline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, section: selected, tag, comment }),
    })
      .then(() => {
        setComments([{ username, section: selected, tag, comment }, ...comments]);
        alert("Redline saved!");
      })
      .catch(() => alert("Error saving redline"));
  };

  // Ask a question to AI (OpenAI, Gemini, LLaMA)
  const handleSend = async () => {
    if (!message.trim()) return;
    try {
      const res = await fetch("http://localhost:8000/llm-router", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, model_name: model }),
      });
      const data = await res.json();
      console.log("AI Reply:", data);
      setReply(data.reply || "");
    } catch {
      alert("AI response failed");
    }
  };

  // Save clause (selected or full text)
  const handleSaveClause = async () => {
    const selected = window.getSelection().toString();
    const clauseText = selected || text || "";
    if (!clauseText) return alert("No clause text to save");

    const title = prompt("Enter clause title:");
    if (!title) return;

    try {
      const res = await fetch("http://localhost:8000/save-clause", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          clause_title: title,
          clause_text: clauseText,
        }),
      });
      const data = await res.json();
      console.log("Saved clause:", data);

      if (data.message) {
        setClauses([{ username, clause_title: title, clause_text: clauseText }, ...clauses]);
        alert("Clause saved!");
      }
    } catch {
      alert("Error saving clause");
    }
  };

  return (
    <div className="chat-container">
      <h1>Contract Analyzer</h1>

      {/* Upload Section */}
      <div className="upload-box">
        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
        <button onClick={handleUpload}>Upload and Extract</button>
        <button onClick={handleHighlightSave}>Save Highlight as Redline</button>
        <button onClick={handleSaveClause}>Save as Clause</button>
      </div>

      {/* Extracted Text Display */}
      <div
        style={{
          marginTop: 20,
          width: "80%",
          marginLeft: "auto",
          marginRight: "auto",
          textAlign: "left",
        }}
      >
        <h3>Extracted Text</h3>
        <div
          style={{
            height: 400,
            overflowY: "scroll",
            border: "1px solid #ccc",
            padding: 16,
            background: "#fff",
            fontSize: "16px",
            color: "#000",
            lineHeight: "1.6",
          }}
        >
          <div>{text || "Upload a PDF to extract text"}</div>
        </div>
      </div>

      {/* AI Chat Section */}
      <div style={{ marginTop: 20 }}>
        <label>Choose model: </label>
        <select value={model} onChange={(e) => setModel(e.target.value)}>
          <option value="openai">OpenAI</option>
          <option value="gemini">Gemini (mock)</option>
          <option value="llama">LLaMA (mock)</option>
        </select>
      </div>

      <div style={{ marginTop: 12 }}>
        <input
          style={{ width: "60%", padding: 8 }}
          type="text"
          placeholder="Ask contract question..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button onClick={handleSend} style={{ marginLeft: 8 }}>
          Send
        </button>
      </div>

      {/* AI Reply */}
      <div
        style={{
          marginTop: 12,
          width: "80%",
          marginLeft: "auto",
          marginRight: "auto",
          textAlign: "left",
        }}
      >
        <h3>AI Reply</h3>
        <div
          style={{
            border: "1px solid #ddd",
            padding: 10,
            background: "#f9f9f9",
            minHeight: "60px",
          }}
        >
          {reply || "No reply yet"}
        </div>
      </div>

      {/* Clauses Display */}
      <div
        style={{
          marginTop: 20,
          width: "80%",
          marginLeft: "auto",
          marginRight: "auto",
          textAlign: "left",
        }}
      >
        <h3>Saved Clauses</h3>
        {clauses.length === 0 ? (
          <div>No clauses saved</div>
        ) : (
          clauses.map((c, i) => (
            <div
              key={i}
              style={{
                borderLeft: "4px solid #007bff",
                margin: "8px 0",
                padding: 8,
                background: "#fff",
              }}
            >
              <b>{c.clause_title}</b>
              <div style={{ marginTop: 6 }}>
                {c.clause_text.slice(0, 300)}
                {c.clause_text.length > 300 ? "..." : ""}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Redlines Display */}
      <div
        style={{
          marginTop: 20,
          width: "80%",
          marginLeft: "auto",
          marginRight: "auto",
          textAlign: "left",
        }}
      >
        <h3>Saved Redlines</h3>
        {comments.length === 0 ? (
          <div>No redlines saved</div>
        ) : (
          comments.map((r, i) => (
            <div
              key={i}
              style={{
                borderLeft: "4px solid #ff9900",
                margin: "8px 0",
                padding: 8,
                background: "#fff",
              }}
            >
              <b>{r.tag}</b> - {r.comment}
              <div style={{ marginTop: 6, fontStyle: "italic" }}>
                {(r.section || "").slice(0, 200)}
                {(r.section || "").length > 200 ? "..." : ""}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default ChatBox;
