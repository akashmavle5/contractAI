import React, { useState, useEffect } from "react"

function ContractGenerator({ username }) {
  const [clauses, setClauses] = useState([])
  const [selected, setSelected] = useState([])
  const [contracts, setContracts] = useState([])
  const [title, setTitle] = useState("")

  useEffect(() => {
    fetch("http://localhost:8000/get-clauses")
      .then((r) => r.json())
      .then((d) => setClauses(d.clauses || []))
    fetchContracts()
  }, [])

  const fetchContracts = () => {
    fetch("http://localhost:8000/get-contracts")
      .then((r) => r.json())
      .then((d) => setContracts(d.contracts || []))
  }

  const toggleClause = (text) => {
    setSelected((prev) =>
      prev.includes(text) ? prev.filter((c) => c !== text) : [...prev, text]
    )
  }

  const handleGenerate = async () => {
    if (!title || selected.length === 0) return alert("Enter title and select clauses")
    const res = await fetch("http://localhost:8000/generate-contract", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, title, clauses: selected })
    })
    const data = await res.json()
    alert(data.message)
    fetchContracts()
  }

  const handleStatus = async (id, newStatus) => {
    await fetch("http://localhost:8000/update-status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: newStatus })
    })
    fetchContracts()
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Contract Generator</h2>

      <input
        type="text"
        placeholder="Enter contract title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        style={{ padding: 8, width: "60%", marginBottom: 10 }}
      />

      <h3>Select Clauses</h3>
      <div style={{ border: "1px solid #ccc", padding: 10, height: 200, overflowY: "scroll" }}>
        {clauses.map((c, i) => (
          <div key={i}>
            <input
              type="checkbox"
              onChange={() => toggleClause(c.clause_text)}
              checked={selected.includes(c.clause_text)}
            />{" "}
            {c.clause_title}
          </div>
        ))}
      </div>

      <button onClick={handleGenerate} style={{ marginTop: 15 }}>Generate Contract</button>

      <h3 style={{ marginTop: 30 }}>Generated Contracts</h3>
      {contracts.map((c, i) => (
        <div key={i} style={{ border: "1px solid #aaa", padding: 10, marginBottom: 10 }}>
          <b>{c.title}</b> - <i>{c.status}</i>
          <p>{c.content.slice(0, 200)}...</p>
          {c.status === "Draft" && (
            <button onClick={() => handleStatus(c.id, "Review")}>Move to Review</button>
          )}
          {c.status === "Review" && (
            <button onClick={() => handleStatus(c.id, "Approved")}>Approve</button>
          )}
        </div>
      ))}
    </div>
  )
}

export default ContractGenerator
