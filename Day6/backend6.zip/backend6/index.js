const express = require("express")
const cors = require("cors")
const mysql = require("mysql2")
const bcrypt = require("bcryptjs")
const multer = require("multer")
const fs = require("fs")
const pdfParse = require("pdf-parse-fixed")
require("dotenv").config()

const app = express()
app.use(cors())
app.use(express.json())

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1111",
  database: "contract_ai"
})

db.connect((err) => {
  if (err) {
    console.error("MySQL connection error:", err)
    process.exit(1)
  }
  console.log("MySQL connected")
})

if (!fs.existsSync("uploads")) fs.mkdirSync("uploads")

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
})
const upload = multer({ storage })

const tableQueries = [
  `CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255)
  )`,
  `CREATE TABLE IF NOT EXISTS redlines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    section TEXT,
    tag VARCHAR(100),
    comment TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS clauses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    clause_title VARCHAR(255),
    clause_text TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS contracts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    title VARCHAR(255),
    content TEXT,
    status ENUM('Draft','Review','Approved') DEFAULT 'Draft'
  )`
]

tableQueries.forEach((query) => {
  db.query(query, (err) => {
    if (err) console.error("Error creating table:", err.sqlMessage)
  })
})

app.post("/signup", async (req, res) => {
  const { username, password } = req.body
  const hashed = await bcrypt.hash(password, 10)
  db.query("INSERT INTO users (username, password) VALUES (?, ?)", [username, hashed], (err) => {
    if (err) return res.status(400).json({ message: "Username exists or error" })
    res.json({ message: "Signup successful" })
  })
})

app.post("/login", (req, res) => {
  const { username, password } = req.body
  db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" })
    if (results.length === 0) return res.status(401).json({ message: "Invalid credentials" })
    const valid = await bcrypt.compare(password, results[0].password)
    if (valid) res.json({ message: "Login successful" })
    else res.status(401).json({ message: "Invalid credentials" })
  })
})

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" })
    const buffer = fs.readFileSync(req.file.path)
    const pdfData = await pdfParse(buffer)
    const text = pdfData.text || ""
    res.json({ text })
  } catch (err) {
    console.error("Upload error:", err)
    res.status(500).json({ message: "Error parsing file" })
  }
})

app.post("/save-redline", (req, res) => {
  const { username, section, tag, comment } = req.body
  db.query("INSERT INTO redlines (username, section, tag, comment) VALUES (?,?,?,?)", [username, section, tag, comment], (err) => {
    if (err) return res.status(500).json({ message: "Error saving redline" })
    res.json({ message: "Redline saved" })
  })
})

app.get("/get-redlines", (req, res) => {
  db.query("SELECT * FROM redlines", (err, results) => {
    if (err) return res.status(500).json({ message: "Error fetching redlines" })
    res.json({ redlines: results })
  })
})

app.post("/save-clause", (req, res) => {
  const { username, clause_title, clause_text } = req.body
  if (!clause_title || !clause_text) return res.status(400).json({ message: "Missing fields" })
  db.query("INSERT INTO clauses (username, clause_title, clause_text) VALUES (?,?,?)", [username, clause_title, clause_text], (err) => {
    if (err) return res.status(500).json({ message: "Error saving clause" })
    res.json({ message: "Clause saved" })
  })
})

app.get("/get-clauses", (req, res) => {
  db.query("SELECT * FROM clauses ORDER BY id DESC", (err, results) => {
    if (err) return res.status(500).json({ message: "Error fetching clauses" })
    res.json({ clauses: results })
  })
})

app.post("/generate-contract", (req, res) => {
  const { username, title, clauses } = req.body
  if (!clauses || clauses.length === 0) return res.status(400).json({ message: "No clauses selected" })
  const content = clauses.join("\n\n")
  db.query("INSERT INTO contracts (username, title, content) VALUES (?,?,?)", [username, title, content], (err) => {
    if (err) return res.status(500).json({ message: "Error saving contract" })
    res.json({ message: "Contract generated successfully" })
  })
})

app.get("/get-contracts", (req, res) => {
  db.query("SELECT * FROM contracts ORDER BY id DESC", (err, results) => {
    if (err) return res.status(500).json({ message: "Error fetching contracts" })
    res.json({ contracts: results })
  })
})

app.post("/update-status", (req, res) => {
  const { id, status } = req.body
  db.query("UPDATE contracts SET status=? WHERE id=?", [status, id], (err) => {
    if (err) return res.status(500).json({ message: "Error updating status" })
    res.json({ message: "Status updated" })
  })
})

const PORT = process.env.PORT || 8000
app.listen(PORT, () => {
  console.log("Server running on port", PORT)
})
//  CONTRACT WORKFLOW + DOWNLOAD 
const path = require("path");
const PDFDocument = require("pdfkit");

// temporary store for contracts
let contracts = [];

// generate contract and save workflow
app.post("/generate-contract", (req, res) => {
  const { username, title, clauses } = req.body;
  if (!title || !clauses || clauses.length === 0)
    return res.status(400).json({ message: "Missing data" });

  const text = clauses.join("\n\n");
  const newContract = {
    username,
    title,
    text,
    status: "Draft",
  };
  contracts.push(newContract);
  res.json({ message: "Contract generated", contract: newContract });
});

// update contract status
app.post("/update-status", (req, res) => {
  const { title, status } = req.body;
  const contract = contracts.find((c) => c.title === title);
  if (!contract) return res.status(404).json({ message: "Contract not found" });
  contract.status = status;
  res.json({ message: "Status updated", contract });
});

// download as PDF
app.get("/download-contract/:title", (req, res) => {
  const title = req.params.title;
  const contract = contracts.find((c) => c.title === title);
  if (!contract) return res.status(404).json({ message: "Contract not found" });

  const filePath = path.join(__dirname, `${title}.pdf`);
  const doc = new PDFDocument();
  doc.pipe(fs.createWriteStream(filePath));

  doc.fontSize(18).text(contract.title, { align: "center" });
  doc.moveDown();
  doc.fontSize(12).text(contract.text, { align: "left" });
  doc.moveDown();
  doc.fontSize(12).text(`Status: ${contract.status}`);

  doc.end();

  doc.on("finish", () => {
    res.download(filePath, `${title}.pdf`, () => {
      fs.unlinkSync(filePath);
    });
  });
});
