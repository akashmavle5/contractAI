import React, { useState } from "react";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isLogin, setIsLogin] = useState(true);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const url = isLogin
      ? "http://localhost:8000/login"
      : "http://localhost:8000/signup";

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    setMessage(data.message);
  };

  return (
    <div style={{ textAlign: "center", marginTop: 50, fontFamily: "Arial" }}>
      <h1>Contract AI Application</h1>

      <div
        style={{
          margin: "20px auto",
          padding: 20,
          width: 320,
          border: "1px solid #ddd",
          borderRadius: 8,
        }}
      >
        <h2>{isLogin ? "Login" : "Signup"}</h2>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{ width: "90%", padding: 8, marginBottom: 10 }}
          />
          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: "90%", padding: 8, marginBottom: 10 }}
          />
          <button
            type="submit"
            style={{
              width: "95%",
              padding: 8,
              background: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: 5,
            }}
          >
            {isLogin ? "Login" : "Signup"}
          </button>
        </form>

        <p style={{ color: message.includes("success") ? "green" : "red" }}>
          {message}
        </p>

        <button
          onClick={() => setIsLogin(!isLogin)}
          style={{
            background: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: 5,
            padding: "6px 10px",
            marginTop: 10,
          }}
        >
          Switch to {isLogin ? "Signup" : "Login"}
        </button>
      </div>
    </div>
  );
}

export default App;
