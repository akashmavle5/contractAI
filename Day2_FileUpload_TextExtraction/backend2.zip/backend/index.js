// IMPORTS 
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const fs = require('fs');
const pdfParse = require('pdf-parse-fixed');

// APP SETUP 
const app = express();
app.use(cors());
app.use(express.json());

//  MYSQL CONNECTION 
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '1111',  // your MySQL password
  database: 'contract_ai'
});

db.connect(err => {
  if (err) throw err;
  console.log('✅ MySQL Connected!');
});

//  ROUTES 

// Default route
app.get('/', (req, res) => {
  res.send('Backend running successfully!');
});

// Signup API
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashed], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Signup successful!' });
  });
});

// Login API
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, result) => {
    if (err) return res.status(500).json({ error: err });
    if (result.length === 0) return res.status(401).json({ message: 'User not found' });

    const valid = await bcrypt.compare(password, result[0].password);
    if (valid) res.json({ message: 'Login successful!' });
    else res.status(401).json({ message: 'Wrong password' });
  });
});

//  FILE UPLOAD + PDF PARSE

// Ensure uploads folder exists
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Upload API
app.post('/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const dataBuffer = fs.readFileSync(req.file.path);
    const pdfData = await pdfParse(dataBuffer);  // use pdfParse here

    console.log(" Extracted text:", pdfData.text.substring(0, 100));
    res.json({ text: pdfData.text });
  } catch (err) {
    console.error(" PDF extraction error:", err);
    res.status(500).json({ error: err.message });
  }
});


// START SERVER (LAST LINE)
app.listen(8000, () => console.log('🚀 Server running on port 8000'));
