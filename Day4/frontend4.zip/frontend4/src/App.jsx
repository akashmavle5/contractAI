import React, { useState } from "react";
import ChatBox from "./ChatBox.jsx";

export default function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");
  const [showChat, setShowChat] = useState(false);
  const [message, setMessage] = useState("");

  //  Login / Signup
  async function handleAuth(e) {
    e.preventDefault();
    const url = isLogin
      ? "http://127.0.0.1:8000/login"
      : "http://127.0.0.1:8000/signup";

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    if (data.message?.includes("successful")) setLoggedIn(true);
    setMessage(data.message || data.detail);
  }

  //  File Upload
  async function handleUpload(e) {
    e.preventDefault();
    if (!file) return alert("Please select a file");

    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch("http://127.0.0.1:8000/upload", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();
    if (data.text) setText(data.text);
    else alert("No text extracted or file unsupported");
  }

  //  Redline Tagging
  async function saveRedline(selectedText) {
    const tag = prompt("Tag name:");
    const comment = prompt("Comment:");
    if (!tag) return;

    await fetch("http://127.0.0.1:8000/save-redline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, section: selectedText, tag, comment }),
    });
    alert("Redline saved!");
  }

  if (!loggedIn)
    return (
      <div className="center">
        <h2>{isLogin ? "Login" : "Signup"}</h2>
        <form onSubmit={handleAuth}>
          <input
            type="text"
            placeholder="Username"
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">{isLogin ? "Login" : "Signup"}</button>
        </form>
        <p>{message}</p>
        <button onClick={() => setIsLogin(!isLogin)}>
          Switch to {isLogin ? "Signup" : "Login"}
        </button>
      </div>
    );

  if (showChat) return <ChatBox goBack={() => setShowChat(false)} />;

  return (
    <div className="page">
      <h1>Contract Upload + Redlining</h1>
      <form onSubmit={handleUpload}>
        <input
          type="file"
          accept=".txt,.pdf,.docx"
          onChange={(e) => setFile(e.target.files[0])}
        />
        <button type="submit">Upload</button>
      </form>

      <div
        className="text-area"
        onMouseUp={() => {
          const selected = window.getSelection().toString();
          if (selected) saveRedline(selected);
        }}
      >
        {text || "Upload a file to see extracted text"}
      </div>

      <div className="btns">
        <button onClick={() => setShowChat(true)}>Chat</button>
        <button onClick={() => setLoggedIn(false)}>Logout</button>
      </div>
    </div>
  );
}
