import React, { useState } from "react";

export default function ChatBox({ goBack }) {
  const [input, setInput] = useState("");
  const [chat, setChat] = useState([]);

  async function send() {
    if (!input) return;
    const res = await fetch("http://127.0.0.1:8000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input }),
    });
    const data = await res.json();
    setChat([...chat, { user: input, bot: data.reply }]);
    setInput("");
  }

  return (
    <div className="chat">
      <h2>💬 Contract Chat</h2>
      <div className="chat-box">
        {chat.length === 0 ? (
          <p style={{ color: "#888" }}>Start chatting with the AI assistant...</p>
        ) : (
          chat.map((m, i) => (
            <p key={i}>
              <b>You:</b> {m.user}
              <br />
              <b>AI:</b> {m.bot}
              <hr />
            </p>
          ))
        )}
      </div>

      <div style={{ marginTop: 10 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your contract..."
          style={{ width: "60%", padding: 8 }}
        />
        <button onClick={send} style={{ marginLeft: 5 }}>
          Send
        </button>
        <button onClick={goBack} style={{ marginLeft: 5 }}>
          Back
        </button>
      </div>
    </div>
  );
}
