# backend/main.py
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3, hashlib, io, os, docx, PyPDF2
from openai import OpenAI
from dotenv import load_dotenv

# ---------- ENV + OPENAI ----------
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# ---------- APP ----------
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- DATABASE ----------
conn = sqlite3.connect("db.sqlite", check_same_thread=False)
cur = conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    password TEXT)""")
cur.execute("""CREATE TABLE IF NOT EXISTS redlines (
    username TEXT,
    section TEXT,
    tag TEXT,
    comment TEXT)""")
conn.commit()

# ---------- HELPERS ----------
def hash_pass(p: str) -> str:
    return hashlib.sha256(p.encode()).hexdigest()

# ---------- MODELS ----------
class Auth(BaseModel):
    username: str
    password: str

class Redline(BaseModel):
    username: str
    section: str
    tag: str
    comment: str

class Chat(BaseModel):
    message: str

# ---------- AUTH ----------
@app.post("/signup")
def signup(data: Auth):
    try:
        cur.execute("INSERT INTO users VALUES (?,?)", (data.username, hash_pass(data.password)))
        conn.commit()
        return {"message": "Signup successful!"}
    except:
        raise HTTPException(status_code=400, detail="Username already exists")

@app.post("/login")
def login(data: Auth):
    cur.execute("SELECT * FROM users WHERE username=? AND password=?", (data.username, hash_pass(data.password)))
    if cur.fetchone():
        return {"message": "Login successful!"}
    raise HTTPException(status_code=401, detail="Invalid credentials")

# ---------- FILE UPLOAD ----------
@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    try:
        content = await file.read()
        name = file.filename.lower()
        text = ""

        # ✅ Extract text from .txt
        if name.endswith(".txt"):
            text = content.decode("utf-8", errors="ignore")

        # ✅ Extract text from .docx
        elif name.endswith(".docx"):
            document = docx.Document(io.BytesIO(content))
            text = "\n".join([p.text for p in document.paragraphs if p.text.strip()])

        # ✅ Extract text from .pdf
        elif name.endswith(".pdf"):
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            extracted_pages = []
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    extracted_pages.append(extracted)
            text = "\n".join(extracted_pages)

        else:
            raise HTTPException(status_code=400, detail="Unsupported file type. Use .txt, .docx, or .pdf")

        if not text.strip():
            text = "⚠️ No readable text found in this file."

        return {"text": text}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File processing error: {str(e)}")

# ---------- REDLINE ----------
@app.post("/save-redline")
def save_redline(data: Redline):
    try:
        cur.execute("INSERT INTO redlines VALUES (?,?,?,?)",
                    (data.username, data.section, data.tag, data.comment))
        conn.commit()
        return {"message": "Redline saved successfully!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")

# ---------- CHAT ----------
@app.post("/chat")
def chat(req: Chat):
    if not client:
        return {"reply": f"(Demo Mode) You said: {req.message}"}
    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": req.message}],
        )
        return {"reply": resp.choices[0].message.content}
    except Exception as e:
        return {"reply": f"AI error: {str(e)}"}

# ---------- HOME ----------
@app.get("/")
def home():
    return {"message": "✅ Backend is running successfully!"}
